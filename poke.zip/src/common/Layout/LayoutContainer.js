import React from 'react'

const LayoutContainer = (props) => (
    <div>
       {props.children}
    </div>
)

export default LayoutContainer

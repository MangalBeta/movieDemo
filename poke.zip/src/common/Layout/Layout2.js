import React from 'react'

const Layout2 = (props) => (
    <div className="container">
                {props.children}
    </div>
)

export default Layout2;

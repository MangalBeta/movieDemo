import React from 'react';
import { Col, Button, ButtonToolbar } from 'react-bootstrap/lib/';

const PaginationNumber = ({ pageArray, onSelect, activePage,previos,next }) => {
    return (
        <nav aria-label="...">
            <ul className="pagination pagination-md">
                {previos &&  <li class="page-item disabled">
                    <a className="page-link" href="javascript:void(0)" tabindex="-1"  onClick={() => onSelect('prev')}>Previous</a>
                </li>}
                {pageArray.map(function (page, index) {
                    return <li key={page}
                        className={activePage === page.page ? "page-item active" : "page-item"}>
                        <a className="page-link"
                            onClick={() => onSelect(page.page)}
                            href="javascript:void(0)">{page.page}</a></li>
                })}
               {next && <li className="page-item">
                    <a className="page-link" href="javascript:void(0)" onClick={() => onSelect('next')}>Next</a>
                </li>} 
            </ul>
        </nav>
    )
}
const PaginationContainer = ({ totalPages, btnSize, activePage, onSelect, previos, next }) => {
    let pageArray = []
    console.log(totalPages, "kk")
    for (let i = 1; i <= 10; i++) {
        pageArray.push({ page: i, })
    }
    return (
        <Col sm={12} >
            {totalPages > 1 ?
                <div>
                    <ButtonToolbar>

                        {/* {previos  ? 
                     <Button onClick={onSelect} 
                        bsStyle={'primary'}>{'Previous'}</Button> : null} */}

                        &nbsp; &nbsp;

                            <PaginationNumber
                            next={next}
                            previos={previos}
                            activePage={activePage}
                            pageArray={pageArray} onSelect={onSelect} />
                        {/* <Button onClick={onSelect} 
                        bsStyle={'primary'}>
                        {'Next'}
                    </Button> */}
                    </ButtonToolbar>

                </div>
                : null}
        </Col>
    )
}

export default PaginationContainer;
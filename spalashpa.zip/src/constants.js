import { Dimensions } from 'react-native';

export const SCREEN_WIDTH = Dimensions.get('window').width;
export const SCREEN_HEIGHT = Dimensions.get('window').height;

export const COVERIMAGE_HEIGHT = SCREEN_WIDTH / 3 * 2;
export const STATUS_BAR_HEIGHT_IOS = 20;

export const API_URL ="http://localhost:9000/index.php"
// export const API_URL ="http://telecomsxchangemarketview.azurewebsites.net/"

export const CountryCode = [
    { code: '770' },
    { code: '771' }, { code: '981' }, { code: '091' }, { code: '111' }, { code: '111' },
    { code: '91' }]
  
export const AreaCode = [
    { code: '21' },
    { code: '22' }, { code: '23' }, { code: '24' }, { code: '25' }, { code: '26' },
    { code: '91' }
]
  
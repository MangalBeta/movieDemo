import React, { Component } from 'react';
import {
  Text,
  StyleSheet,
  View,
  Dimensions,
  TouchableOpacity
} from 'react-native';
import Modal from "react-native-modal";

import text from '../style/text';
import color from '../style/color';

const { height, width } = Dimensions.get('window');
import NextButton from '../components/Button';
export default class AlertModal extends Component {

  state = {
    modalVisible: false,
  }
  render() {
    return (
      <Modal
        isVisible={this.props.modalVisible}
        backdropColor={'rgba(0.30,0.30,0.30,0.70)'}
        backdropOpacity={0.4}
        onBackdropPress={this.props.closeModal}
        style={{ width: '100%', alignSelf: 'center' }}>
        <View style={[styles.modalView,{flex:this.props.flex ? this.props.flex : 1}]}>
          <View style={styles.ModalInsideView}>
           {this.props.children}
           <NextButton buttonText={this.props.buttonText} onForward={this.props.closeModal} width='100%'/>

          </View>
        </View>
      </Modal>

    );
  }
}

const styles = StyleSheet.create({
  ModalInsideView: {
    flex:0.6,
    backgroundColor: "#fff",
    width: width - 50,
    paddingHorizontal: 10,
    paddingVertical: 10,
    alignSelf: 'center',
    borderRadius: 15,
    borderWidth: 1,
    borderColor: '#fff',
    marginTop:50
  },
  modalView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  buttonText: {
    color: color.white,
    textAlign:'center'
  }
});

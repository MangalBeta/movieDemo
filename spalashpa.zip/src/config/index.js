import {Platform} from 'react-native';

const config = {
    apiKey: "AIzaSyDoIbqqdjLpVr6cwhQ3VUNB3Q5opsqUSZI",
    authDomain: "ratesalertclient.firebaseapp.com",
    databaseURL: "https://ratesalertclient.firebaseio.com",
    projectId: "ratesalertclient",
    storageBucket: "ratesalertclient.appspot.com",
    messagingSenderId: "739148575807",
}

export const appConfig = config

import React, { Component } from 'react';
import {
  DrawerNavigator,
  StackNavigator,
  TabNavigator,
  addNavigationHelpers
} from 'react-navigation';

import Welcome from './containers/Welcome';
import Email from './scenes/Auth/Email';
import Password from './containers/Password';
 import Dashboard from './scenes/Dashboard';

// Auth Navigator 
const Auth = StackNavigator({
    Email: {
      screen: Email,
      navigationOptions: {
        header: null
      },
  
    },
    Password: {
      screen: Password,
      navigationOptions: {
        header: null
      }
    }
  }, {
      initialRouteName: "Email",
  
    })

    // Drawer Navigator 
const Drawer = StackNavigator({
  Dashboard: {
    screen: Dashboard,
    navigationOptions: {
      header: null
    },

  },
}, {
    initialRouteName: "Dashboard",

  })

//Root navigator
export const createRootNavigator = (user) => {
    return StackNavigator({
      Welcome: {
        screen: Welcome,
        navigationOptions: {
          header: null
        },
      },
      Drawer: {
        screen: Drawer,
        navigationOptions: {
          header: null
        },
      },
      Auth: {
        screen: Auth,
        navigationOptions: {
          header: null
        },
      },
    }, {
        //initialRouteName: "Drawer"
        initialRouteName: "Welcome",
      })
  }
  
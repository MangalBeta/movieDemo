/**
 * Picker.js
 *
 * ## Function
 * It defines a basic Picker component,with some default settings.
 * To customize it, simply override the style code.
 *
 * ## Touch event
 *  @param onChange: defines the event when user change the input
 *
 
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';

import {
  Text,
  View,
  StyleSheet,
  Dimensions,
  PickerIOS,
  TouchableHighlight
} from 'react-native';
import position from '../style/position';
var PickerItemIOS = PickerIOS.Item;

const propTypes = {
  pickerItems: PropTypes.array,
  closeModal: PropTypes.func,
};

export default class Picker extends Component {
  constructor(props) {
    super(props)
  }
  closeModal() {
    this.props.closeModal()
  }
  render() {
    return (
      <View style={[position.picker]}>
        <View style={styles.closeButtonContainer}>
          <TouchableHighlight onPress={this.closeModal.bind(this)} underlayColor="transparent"
            style={styles.closeButton}>
            <Text style={styles.closeButtonText}>Choose</Text>
          </TouchableHighlight>
        </View>
        <PickerIOS
          itemStyle={{ paddingBottom: 20 }}
          selectedValue={this.props.selectedValue}
          onValueChange={(item) => this.props.changePiker(item)}>
          {Object.keys(this.props.pickerItems).map((item) => (
            <PickerItemIOS
              key={item}
              value={this.props.pickerItems[item].code}
              label={this.props.pickerItems[item].code}
            />
          ))}
        </PickerIOS>
      </View>
    )
  }
}
Picker.propTypes = propTypes;

var styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 60
  },
  showtimeContainer: {
    borderTopColor: '#ededed',
    borderTopWidth: 1
  },
  showtime: {
    padding: 20,
    textAlign: 'center'
  },
  button: {
    marginTop: 25,
    marginBottom: 25
  },
  closeButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    borderTopColor: '#e2e2e2',
    borderTopWidth: 1,
    borderBottomColor: '#e2e2e2',
    borderBottomWidth: 1
  },
  closeButton: {
    paddingRight: 10,
    paddingTop: 10,
    paddingBottom: 10
  },
  buttonText: {
    textAlign: 'center'
  },
  closeButtonText: {
    color: '#027afe'
  },
});
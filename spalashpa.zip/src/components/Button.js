/**
 * Button.js
 *
 * ## Function
 * It defines a basic button component,with some default settings.
 * To customize it, simply override the style code.
 *
 * ## Touch event
 *  @param onPress: defines the event when user pressing the button
 *
 * ## PropTypes
 *  @param btnText: 'this is a button text'
 *  @param onForward: configure its forwarding (for navigator) scene
 *  @param style: customized style
 *
 * @
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  View,
  TouchableOpacity,
  Text,
  StyleSheet,
} from 'react-native';

import text from '../style/text';
import color from '../style/color';

const propTypes = {
  btnText: PropTypes.string,
  onForward: PropTypes.func,
};

export default class Button extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
        <TouchableOpacity hitSlop={{ right: 20, left: 20, top: 20, bottom: 20 }}
          onPress={this.props.onForward}
          style={{
             padding: 10, marginTop: 20, backgroundColor:this.props.backgroundColor?  this.props.backgroundColor:'#D8D8D8',
            justifyContent: 'center',
            alignItems: 'center' 
          }}
          >
           <Text style={{ fontSize: 18, alignSelf: 'center', color: '#000' }}>{this.props.buttonText}</Text>

        </TouchableOpacity>

    );
  }
}

Button.propTypes = propTypes;

const styles = StyleSheet.create({
 
  buttonText: {
    alignSelf: 'center', color: color.white,fontSize:18 ,
  }
});

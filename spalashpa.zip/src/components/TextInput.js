/**
 * TextInput.js
 *
 * ## Function
 * It defines a basic TextInput component,with some default settings.
 * To customize it, simply override the style code.
 *
 * ## Touch event
 *  @param onChange: defines the event when user change the input
 *
 * ## PropTypes
 
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  View,
  TouchableOpacity,
  Text,
  TextInput,
  StyleSheet,
} from 'react-native';

import text from '../style/text';
import color from '../style/color';
import DownIcon from '../components/DownIcon';
import textInput from '../style/textInput';

const propTypes = {
  placeHolderText: PropTypes.string,
  onChange: PropTypes.func,
  refField:PropTypes.string,
  editable : PropTypes.bool,
  keyboardType : PropTypes.string
};

export default class CustomeTextInput extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
        <TextInput {...this.props.input}  
                  style={textInput.input}
                  underlineColorAndroid='transparent'
                  placeholder={this.props.placeholder}
                  placeholderTextColor="#a4a3a8"
                  onChangeText={this.props.onChangeText}  
                  name={this.props.name}
                  keyboardType = {this.props.keyboardType}
                  autoCorrect = {false}
                  autoCapitalize = {'none'}
                  value={this.props.value}
                  ref = {this.props.refField}
                  editable = {this.props.editable}
         />

    );
  }
}

CustomeTextInput.propTypes = propTypes;

const styles = StyleSheet.create({
 textInputContainer:{
        height: 75, width: "100%", paddingHorizontal: 15,
        color: '#000',fontFamily: 'Gotham-Light',
        fontSize: 20,
        alignSelf:'center',
        borderColor: color.lightGray
 }
});

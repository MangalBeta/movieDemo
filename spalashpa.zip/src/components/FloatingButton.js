import React, { Component } from 'react';

import { StyleSheet, View, Image, TouchableOpacity } from 'react-native';
import FloatImage from '../../public/image/_0000_Add-btn.png'
export default class FloatButton extends Component {
    render() {
        return (
                <TouchableOpacity activeOpacity={0.5} onPress={this.props.floatButton} style={styles.TouchableOpacityStyle} >
                    <Image source={FloatImage}
                        style={styles.FloatingButtonStyle} />
                </TouchableOpacity>
        );
    }
}
const styles = StyleSheet.create({
    FloatContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'red'
    },
    TouchableOpacityStyle: {
        position: 'absolute',
        width: 50,
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
        right: 10,
        bottom: 10,
    },
    FloatingButtonStyle: {
        resizeMode: 'contain',
        width: 75,
        height: 75,
    }
});
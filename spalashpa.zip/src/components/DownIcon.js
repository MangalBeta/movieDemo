/**
 * DownIcon.js
 *
 *
 * @
 */

import React, { Component } from 'react';
import {
  View,
  Image,
  StyleSheet
} from 'react-native';


export default class DownIcon extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
        <View style={this.props.style ? this.props.style : styles.iconContainer}>
          <Image source={require('../../public/image/arrow.png')} style={{ alignSelf: 'center' }} />
      </View>

    );
  }
}

const styles = StyleSheet.create({
  iconContainer:{
    justifyContent: 'center', flex: 0.1, alignItems: 'center'
  }
 });
 


/**
 * App.js
 *
 * main app file
 *
 * @zchen
 */

import React, { Component } from 'react';
import {
  DrawerNavigator,
  StackNavigator,
  TabNavigator,
  addNavigationHelpers
} from 'react-navigation';
import { Provider } from 'react-redux'
import { Platform } from 'react-native'
import {
  DEFAULT_TEA_LIST,
  CUSTOMIZED_TEA_LIST_STORAGE_KEY,
  CUSTOMIZED_SETTINGS_STORAGE_KEY,
} from './constants';
import {createRootNavigator} from './routes'

import configureStore from './redux/store/configure-store'
const store = configureStore()

export default class App extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    const Layout = createRootNavigator();
    return (
      <Provider store={store}>
      <Layout />
      </Provider>
    );
  }
}

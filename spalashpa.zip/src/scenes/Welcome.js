/**
 * Welcome.js
 *
 * @
 */
import React, { Component } from 'react';
import {
  Text,
  ImageBackground,
  View,
  Image,
  Dimensions,
  TextInput,
  StatusBar,
  TouchableOpacity
} from 'react-native';

import { connect } from 'react-redux'
import {
  STATUS_BAR_HEIGHT_IOS,
} from '../constants';
const { height, width } = Dimensions.get('window');
import Icon from 'react-native-vector-icons/Entypo';
import EvilIcons from 'react-native-vector-icons/FontAwesome';


const bgimage = require('../../public/image/Mask.png');
const bitMap = require('../../public/image/Bitmap.png');

const emailIcon = require('../../public/image/envelope.png')
const speechMessage = require('../../public/image/icon-speech-message.png')
const questionMark = require('../../public/image/question-mark.png')
const dotImage = require('../../public/image/spinner-of-dots.png')

export default class Welcome extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  componentDidMount(){
    setTimeout(() => {
      this.props.navigation.navigate('Auth')
   },2000)
  }

  render() {
    return (
      <View style={{
        flex: 1, justifyContent: 'center', alignContent: 'center',
      }}>
       <StatusBar
     backgroundColor="#515183"
     barStyle="light-content"
   />
      <ImageBackground source={bgimage} style={{ width: '100%', height: '100%', marginBottom: 0 }} resizeMode="cover">
      <ImageBackground source={bitMap} style={{ width: '100%', height: '100%', marginBottom: 0 }} resizeMode="cover">
        <View style={{ flex: .8,alignItems: 'center', justifyContent:'flex-end'}}>
          <View style={{width:'60%', flexDirection: 'row' ,
          alignItems:'center',}}>
          <Image source={speechMessage} style={{marginRight:'10%',alignSelf:'center'}} /> 
            {/* <Icon name="message" size={48} color="#FFF" style={{paddingHorizontal:10,alignSelf:'flex-start'}} /> */}
            <Text style={{ color: "#FFF", fontSize: 32,alignSelf:'flex-end' ,fontFamily:'Helvetica'}}>Chat 4.0</Text>
          </View>
          <View style={{width:'100%', justifyContent:'center', flexDirection: 'row' ,alignItems:'center'}}>
          <Text style={{ color: "#E7F7FE",fontSize:16,lineHeight:40 ,alignSelf:'center'}}>Full UX Design For Chat Apllication</Text>
          </View>
        </View>
          <View style={{flex:0.8,justifyContent:'flex-start',marginTop:'20%',alignItems:'center'}}>
          <Image source={dotImage} style={{marginRight:'10%',alignSelf:'center'}} /> 
           </View>
        </ImageBackground>
      </ImageBackground>
      </View>

    );
  }
}



/**
 * Welcome.js
 *
 * @
 */
import React, { Component } from 'react';
import {
  Text,
  ImageBackground,
  View,
  Image,
  Dimensions,
  StatusBar,
  TouchableOpacity
} from 'react-native';

import {
  STATUS_BAR_HEIGHT_IOS,
} from '../../constants';
const { height, width } = Dimensions.get('window');
import Icon from 'react-native-vector-icons/Entypo';
import EvilIcons from 'react-native-vector-icons/FontAwesome';

import { EmailValidation ,RequiredValidation} from '../../utils/validation'

import textInput from '../../style/textInput';

const bgimage = require('../../../public/image/Mask.png');
const bitMap = require('../../../public/image/Bitmap.png');

const Userpic = require('../../../public/image/Userpic.png')
const speechMessage = require('../../../public/image/icon-speech-message.png')
const questionMark = require('../../../public/image/question-mark.png')

import Button from '../../components/Button';
import AlertModal from '../../modals/AlertModal'
import TextInput from '../../components/TextInput'
import position from '../../style/position';

export default class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {emailError:null};
  }

 

  closeModal() {
    this.setState({ modalVisible: false })
  }

  render() {
    return (
        <View style={{
            flex: 1, justifyContent: 'center', alignContent: 'center',
          }}>
           <StatusBar
         backgroundColor="#515183"
         barStyle="light-content"
       />
          <ImageBackground source={bgimage} style={{ width: '100%', height: '100%', marginBottom: 0 }} resizeMode="cover">
          <ImageBackground source={bitMap} style={{ width: '100%', height: '100%', marginBottom: 0 }} resizeMode="cover">
            <View style={{flex:0.2,justifyContent:'flex-end', alignItems: 'flex-end'}}>
            <Image source={questionMark} style={{alignSelf:'flex-end',paddingHorizontal:25}} resizeMode="contain" /> 
    
            </View>
            <View style={{ flex: 2.5, alignItems: 'center', justifyContent:'center'}}>
            <View style={{flexDirection: 'row' ,flex:0.2,
              alignItems:'center',}}>
                <Image source={Userpic} style={{alignSelf:'center'}}
                 resizeMode="contain" />

              </View>
              <View style={{flexDirection: 'row' ,
              alignItems:'center',}}>
                <Text style={{ color: "#FFF", fontSize: 20,alignSelf:'center' ,
                fontFamily:'Helvetica'}}>test@yopmail.com</Text>
              </View>
              <View style={{width:'60%', justifyContent:'center', flexDirection: 'row' ,alignItems:'center'}}>
              <Text style={{ color: "#E7F7FE",
              fontSize:16,lineHeight:30 ,alignSelf:'center',textAlign:'center'}}>
             WelcomeTo Dashboard
              </Text>
              </View>
            </View>
           
         
    
            </ImageBackground>
          </ImageBackground>
          </View>
    );
  }
}



/**
 * Welcome.js
 *
 * @
 */
import React, { Component } from 'react';


import {
  Text,
  ImageBackground,
  View,
  Image,
  Dimensions,
  StatusBar,
  TouchableOpacity
} from 'react-native';

import {
  STATUS_BAR_HEIGHT_IOS,
} from '../../constants';
const { height, width } = Dimensions.get('window');
import Icon from 'react-native-vector-icons/Entypo';
import EvilIcons from 'react-native-vector-icons/FontAwesome';

const FBSDK = require('react-native-fbsdk');
const {
  LoginManager,
} = FBSDK;

import { EmailValidation ,RequiredValidation} from '../../utils/validation'

import textInput from '../../style/textInput';
import text from '../../style/text';

const bgimage = require('../../../public/image/Mask.png');
const bitMap = require('../../../public/image/Bitmap.png');

const emailIcon = require('../../../public/image/envelope.png')
const speechMessage = require('../../../public/image/icon-speech-message.png')
const questionMark = require('../../../public/image/question-mark.png')

import Button from '../../components/Button';
import AlertModal from '../../modals/AlertModal'
import TextInput from '../../components/TextInput'
import position from '../../style/position';

export default class Email extends Component {
  constructor(props) {
    super(props);
    this.state = {emailError:null};
  }

  nextButton(){
    if (this.state.email && !this.state.emailError) {
      this.props.navigation.navigate('Password',
      {'email':this.state.email})
    } else {
      this.setState({ modalVisible: true,errorMessage:'Email is required' })
    }

  }

  closeModal() {
    this.setState({ modalVisible: false })
  }
  //Facebook Login
  loginByFacebook=() =>{
   LoginManager.logInWithReadPermissions(['public_profile']).then(
      (result) => {
    if (result.isCancelled) {
      alert('Login cancelled');
    } else {
      alert('Login success with permissions: '
        +result.grantedPermissions.toString());
    }
  },
  (error) => {
    alert('Login fail with error: ' + error);
  }
);
  }

  render() {
    return (
      <View style={{
        flex: 1, justifyContent: 'center', alignContent: 'center',
      }}>
       <StatusBar
     backgroundColor="#515183"
     barStyle="light-content"
   />
      <ImageBackground source={bgimage} style={{ width: '100%', height: '100%', marginBottom: 0 }} resizeMode="cover">
      <ImageBackground source={bitMap} style={{ width: '100%', height: '100%', marginBottom: 0 }} resizeMode="cover">
        <View style={{flex:0.4,justifyContent:'flex-end', alignItems: 'flex-end'}}>
        <Image source={questionMark} style={{alignSelf:'flex-end',paddingHorizontal:25}} resizeMode="contain" /> 

        </View>
        <View style={{ flex: 2, alignItems: 'center', justifyContent:'center'}}>
          <View style={{width:'60%', flexDirection: 'row' ,
          alignItems:'center',}}>
          <Image source={speechMessage} style={{marginRight:'10%',alignSelf:'center'}} /> 
            {/* <Icon name="message" size={48} color="#FFF" style={{paddingHorizontal:10,alignSelf:'flex-start'}} /> */}
            <Text style={{ color: "#FFF", fontSize: 32,alignSelf:'flex-end' ,fontFamily:'Helvetica'}}>Chat 4.0</Text>
          </View>
          <View style={{width:'100%', justifyContent:'center', flexDirection: 'row' ,alignItems:'center'}}>
          <Text style={{ color: "#E7F7FE",fontSize:16,lineHeight:40 ,alignSelf:'center'}}>Full UX Design For Chat Apllication</Text>
          </View>
        </View>
        <View style={{ flex: 1, paddingHorizontal: 20 }} >
          <View style={{ flexDirection: 'row', backgroundColor: '#fff',borderColor: 'gray', borderWidth: 1, }}>
            <Image source={emailIcon} style={{alignSelf:'center',marginLeft:10}} resizeMode="cover" /> 
            <TextInput
              placeholder={"Enter email address"}
              placeholderTextColor={'#9B9B9B'}
              onChangeText={(email) => this.setState({ email,
              emailError: EmailValidation(email, 'Email')})}
              value={this.state.email}
            />
          
          </View>
          {this.state.emailError && <Text style={{color:'red'}}>{this.state.emailError}</Text>
            }
         <Button  backgroundColor="#D8D8D8" buttonText="Login" onForward={this.nextButton.bind(this)}/>
        </View>
        <View style={{
          flex: 1, justifyContent: 'flex-end', alignItems: 'center',
          marginBottom: 20
        }}>
          <View style={{ flexDirection: 'row', marginBottom: 20,alignItems:'center',
          justifyContent:'center' }}>
          <TouchableOpacity onPress={() => this.loginByFacebook()}>
            <Icon name="facebook-with-circle" size={30} color="#FFF" />
            </TouchableOpacity>
            <TouchableOpacity>
            <Icon name="google-" size={30} color="#FFF" style={{ marginLeft: 20 }} />
            </TouchableOpacity>
            <TouchableOpacity>
            <Icon name="mobile" size={30} color="#FFF" style={{ marginLeft: 20 }} />
            </TouchableOpacity>
          </View>
        </View>

        <TouchableOpacity style={{ flex: 0.3, justifyContent: 'flex-start', alignItems: 'center', marginBottom: 20 }}>
          <Text style={{ color: '#FFF', fontSize: 18 }}>REGISTER NEW ACCOUNT</Text>
        </TouchableOpacity>
        <AlertModal
            flex={0.6}
            modalVisible={this.state.modalVisible}
            buttonText="OK"
            closeModal={this.closeModal.bind(this)}
          >
            <View style={{ paddingVertical: 10, width: '100%' }}>
              <View style={{ paddingVertical: 15, }}>
                <Text style={[text.p, { fontSize: 16 }]}>{this.state.errorMessage}</Text>
              </View>
            </View>
          </AlertModal>
        </ImageBackground>
      </ImageBackground>
      </View>

    );
  }
}



/**
 * Welcome.js
 *
 * @
 */
import React, { Component } from 'react';
import {
  Text,
  ImageBackground,
  View,
  Image,
  Dimensions,
  StatusBar,
  TouchableOpacity
} from 'react-native';

import {
  STATUS_BAR_HEIGHT_IOS,
} from '../../constants';
const { height, width } = Dimensions.get('window');
import Icon from 'react-native-vector-icons/Entypo';
import EvilIcons from 'react-native-vector-icons/FontAwesome';
import { RequiredValidation} from '../../utils/validation'


import textInput from '../../style/textInput';
import text from '../../style/text';

const bgimage = require('../../../public/image/Mask.png');
const bitMap = require('../../../public/image/Bitmap.png');

const Userpic = require('../../../public/image/Userpic.png')
const speechMessage = require('../../../public/image/icon-speech-message.png')
const questionMark = require('../../../public/image/question-mark.png')

import Button from '../../components/Button';
import AlertModal from '../../modals/AlertModal'
import TextInput from '../../components/TextInput'
import position from '../../style/position';

export default class Password extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: (this.props.navigation.state.params)?
      this.props.navigation.state.params.email : 'test@yopmail.com',
      error:null
    };
  }

  nextButton() {
    if (this.state.email && this.state.password) {
      let user = {}
      user['email'] = this.state.email;
      user['password'] = this.state.password
      this.props.loginUser(user).then((res) =>{
        this.props.navigation.navigate('Dashboard',
        {'email':this.state.email})     
       }).catch((err) =>{
        this.setState({ modalVisible: true,errorMessage:err.message })

      })
    } else {
      this.setState({ modalVisible: true })
    }

  }

  closeModal() {
    this.setState({ modalVisible: false })
  }

  render() {
    return (
      <View style={{
        flex: 1, justifyContent: 'center', alignContent: 'center',
      }}>
       <StatusBar
     backgroundColor="#515183"
     barStyle="light-content"
   />
      <ImageBackground source={bgimage} style={{ width: '100%', height: '100%', marginBottom: 0 }} resizeMode="cover">
      <ImageBackground source={bitMap} style={{ width: '100%', height: '100%', marginBottom: 0 }} resizeMode="cover">
        <View style={{flex:0.4,justifyContent:'flex-end', alignItems: 'flex-end'}}>
        <Image source={questionMark} style={{alignSelf:'flex-end',paddingHorizontal:25}} resizeMode="contain" /> 

        </View>
        <View style={{ flex: 2, alignItems: 'center', justifyContent:'center'}}>
        <View style={{flexDirection: 'row' ,flex:0.2,
          alignItems:'center',}}>
            <Image source={Userpic} style={{alignSelf:'center'}}
             resizeMode="contain" />

          </View>
          <View style={{flexDirection: 'row' ,flex:0.2,
          alignItems:'center',}}>
            <Text style={{ color: "#FFF", fontSize: 20,alignSelf:'flex-end' ,
            fontFamily:'Helvetica'}}>{this.state.email}</Text>
          </View>
          <View style={{width:'60%', justifyContent:'center', flexDirection: 'row' ,alignItems:'center'}}>
          <Text style={{ color: "#E7F7FE",
          fontSize:16,lineHeight:30 ,alignSelf:'center',textAlign:'center'}}>
          Lets enter password to join 
          TalkRemit!
          </Text>
          </View>
        </View>
        <View style={{ flex: 1, paddingHorizontal: 20 }} >
          <View style={{ flexDirection: 'row', backgroundColor: '#fff',
          borderColor: 'gray', borderWidth: 1, }}>
            {/* <Image source={emailIcon} style={{alignSelf:'center',marginLeft:10}} resizeMode="cover" />  */}
            <TextInput
              placeholder={"Enter your password"}
              placeholderTextColor={'#9B9B9B'}
              onChangeText={(password) => this.setState({ password,
                error: RequiredValidation(password, 'Password') })}
              value={this.state.password}
            />
          </View>
          {this.state.error && <Text style={{color:'red'}}>{this.state.error}</Text>
            }
         <Button  backgroundColor="#D8D8D8" buttonText="Confirm" onForward={this.nextButton.bind(this)}/>
        </View>
        <View style={{
          flex: 1, justifyContent: 'flex-end', alignItems: 'center',
          marginBottom: 20
        }}>
        
         <TouchableOpacity style={{ flex: 1, justifyContent: 'flex-start', alignItems: 'center', marginBottom: 20 }}>
          <Text style={{ color: '#FFF', fontSize: 18 }}>FORGOT PASSWORD? RESET</Text>
        </TouchableOpacity>
          </View>

        <TouchableOpacity style={{ flex: 0.3, justifyContent: 'flex-start', alignItems: 'center', marginBottom: 20 }}>
          <Text style={{ color: '#FFF', fontSize: 18 }}>USE OTHER ACCOUNT</Text>
        </TouchableOpacity>
        <AlertModal
            flex={0.6}
            modalVisible={this.state.modalVisible}
            buttonText="OK"
            closeModal={this.closeModal.bind(this)}
          >
            <View style={{ paddingVertical: 10, width: '100%' }}>
              <View style={{ paddingVertical: 15, }}>
                <Text style={[text.p, { fontSize: 16 }]}>{this.state.errorMessage}</Text>
              </View>
            </View>
          </AlertModal>
        </ImageBackground>
      </ImageBackground>
      </View>

    );
  }
}



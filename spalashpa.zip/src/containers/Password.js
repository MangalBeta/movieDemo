import { connect } from 'react-redux'
import * as authAction from '../redux/actions/auth'
import Password from '../scenes/Auth/Password'

function mapStateToProps(state) {
  const { isFetched, success,error,user } = state.auth
  return {
    isFetched,
    error,
    success,
    user
  }
}
const mapDispatchToProps = {
    loginUser: authAction.loginUser,
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Password)

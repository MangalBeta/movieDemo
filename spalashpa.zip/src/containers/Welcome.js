import { connect } from 'react-redux'
import * as authAction from '../redux/actions/auth'
import Welcome from '../scenes/Welcome'

function mapStateToProps(state) {
  const { isFetched, success,error,user } = state.auth
  return {
    isFetched,
    error,
    success,
    user
  }
}
const mapDispatchToProps = {
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Welcome)

import { StyleSheet } from 'react-native';

const colorScheme = {
  color1: '#9FD5C0',
  color2: '#DBEBC2',
  color3: '#FDD2B5',
  color4: '#F7A7A6',
  color5: '#F48B94',
  color6:'#fffff',
  color7:'transparent'
};

export default colorScheme;

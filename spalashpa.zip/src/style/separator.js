
import { StyleSheet } from 'react-native';
import color from './color';
const textInput = StyleSheet.create({
    separator: {
        height: 0.5,
        width: "80%",
        alignSelf: 'center',
        backgroundColor: "#555"
      },
    
  });

export default textInput;

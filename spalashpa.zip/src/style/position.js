import { StyleSheet,Dimensions } from 'react-native';
import { STATUS_BAR_HEIGHT_IOS } from '../constants';

const {  height } = Dimensions.get('window')
const position = StyleSheet.create({
  topLeft: {
    position: 'absolute',
    top: STATUS_BAR_HEIGHT_IOS,
    left: 10,
    zIndex: 5,
  },
  topRight: {
    position: 'absolute',
    top: STATUS_BAR_HEIGHT_IOS,
    right: 10,
    zIndex: 5,
  },
  bottom: {
    position: 'absolute',
    bottom: 0,
    zIndex: 5,
  },
  modalPosition:{
    position: 'absolute',
    top: height / 3 + 30,
    zIndex: 100,
    flex: 1,
    // justifyContent: 'center',
    flexDirection: 'row',
     paddingLeft: 20, paddingRight: 20,
  },
  picker : {
    position:'absolute',bottom:0,
    backgroundColor:'white',
    zIndex:1000,right:0,
    left:0,
    borderBottomRightRadius:15,
    borderBottomLeftRadius:15
  }
});

export default position;

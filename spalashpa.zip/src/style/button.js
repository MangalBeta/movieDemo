
import { StyleSheet } from 'react-native';
import color from './color';

const button = StyleSheet.create({
    buttonContainer: {
        flex: 1, justifyContent: 'center',
        borderBottomRightRadius: 15, borderBottomLeftRadius: 15, backgroundColor: color.lightGray
    },
    btnContainerGrey: {
        borderBottomRightRadius: 15, borderBottomLeftRadius: 15,
        backgroundColor: color.lightGray,
        flex: 0.2,
        justifyContent: 'flex-end',
    },
});

export default button;


import { StyleSheet } from 'react-native';
import color from './color';

const textInput = StyleSheet.create({
    textInputContainer : {
        shadowColor: '#999',
        shadowOpacity: 0.1,
        shadowRadius: 20,
        elevation: 10,
        justifyContent:'space-between',
        borderRadius: 50/2,
        height: 50,
        flexDirection:'row',
        width: "100%",  borderWidth: 1,
        borderColor: color.lightGray,
        paddingHorizontal: 20,
      },
      input : {
        flex:1,
        marginLeft:10,
        height: 40,  fontSize: 16,
        paddingLeft: 25,
        textShadowColor:'#9B9B9B'
      }
  });

export default textInput;

import { StyleSheet } from 'react-native';
import color from './color';

const text = StyleSheet.create({
    p: {
      color: 'black',
      fontFamily: 'Gotham-Light',
      fontSize: 14,
      textAlign:'center',
      lineHeight:30

    },
    title: {
      color: 'black',
      fontFamily: 'Gotham-Medium',
      fontSize: 20,
    },
    mainTitle:{
      color: 'white',
      lineHeight:38,
      fontFamily: 'Gotham-Medium',
      fontSize: 24,
    },
    number: {
      color: 'black',
      fontFamily: 'Gotham',
      fontSize: 20,
    },
    button: {
      color: 'white',
      fontFamily: 'Gotham-Light',
      fontSize: 16,
      fontWeight: 'bold'
    },
    subTitle: {
      color: 'gray',
      fontFamily: 'Gotham-Black',
      fontSize: 14,
      // fontWeight:'100'
    },
    sectionTitle: {
      // color: 'black',
      // fontFamily: 'Gotham-Black',
      fontSize: 20,
      fontWeight:'600'
    },
    shadow: {
      shadowOffset: {
        width: 1,
        height: 1
      },
      shadowColor: 'black',
      shadowOpacity: 1
    },
    labelText: {
      color: 'white',
      fontFamily: 'Gotham-Bold',
      fontSize: 10,
    }
  });

export default text;

import { StyleSheet, Dimensions } from 'react-native';

const { height } = Dimensions.get('window')
const containers = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 8,
  },
  row: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center'
  },
  stickyFooter: {
    position: 'absolute',
    bottom: 0,
  },
  shadowDiv: {
    shadowOffset: {
      width: 1,
      height: 1
    },
    shadowColor: 'black',
    shadowOpacity: 1
  },
  modalView: {
    flex: 1, alignItems: 'center', borderRadius: 15,
    borderColor: 'transparent',
    justifyContent: 'center',
    paddingVertical: 20,
    backgroundColor: "white",
    // width: 100,
    height: 'auto',
    shadowColor: '#999',
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.7,
    shadowRadius: 18,
    elevation: 25,
  }
});

export default containers;

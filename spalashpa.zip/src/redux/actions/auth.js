import {
  GET_LOGIN_REQUEST,
  GET_LOGIN_SUCCESS,
  GET_LOGOUT_SUCCESS
} from '../constants/auth'

import * as firebase from 'firebase'

import {API_URL} from '../../constants'

function setUser(data) {
  return {
    type: GET_LOGIN_SUCCESS,
    payload: data
  }
}

function saveUserDb(data){
    return new Promise((resolve, reject) => {
      firebase.database().ref('users/').push().then((insertedKey) => {
        data['key'] = insertedKey.key;
        firebase.database().ref(`users/${insertedKey.key}`).set(data).then(function () {
            resolve("success");
        }, function (err) {
            reject(err);
        });
    })
  })
}


export function loginUser(data) {
  return dispatch => {
    dispatch({
      type: GET_LOGIN_REQUEST
    })
    return new Promise((resolve, reject) => {
      firebase.auth().signInWithEmailAndPassword(data.email, data.password)
      .then((success) => {
          resolve(success)
      },
        (error) => {
          reject(error)

        });
    })
  }
}

function checkUserExits(email){
  firebase.database().ref(`users/`).orderByChild('api_key').equalTo(data.api_key).once('value', (snapshot) => {
    debugger
    if(!snapshot.exists()){
      saveUserDb(data)
    }
}, function (err) {
    reject(err);
})
}

export function logOutUser() {
  return dispatch => {
    return new Promise((resolve, reject) => {
      dispatch({
        type: GET_LOGOUT_SUCCESS
      })
      resolve('success')
    })
  }
  
}

export const RequiredValidation = (value, name) => {
    return (
        value ? undefined : (name + ' is required')
    )
}
export const EmailValidation = value => {
    return (
        value && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,5}$/i.test(value) ? 'Invalid email address' : undefined
    )
}

